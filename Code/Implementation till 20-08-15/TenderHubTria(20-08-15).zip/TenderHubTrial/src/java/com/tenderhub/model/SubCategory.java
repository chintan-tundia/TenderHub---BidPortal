package com.tenderhub.model;

public class SubCategory {    
    public int sub_cat_id;
    public String sub_cat_name;
    public int category_id;

    public SubCategory( int sub_cat_id, String sub_cat_name,int category_id) {
        this.sub_cat_name = sub_cat_name;
        this.sub_cat_id = sub_cat_id;
        this.category_id = category_id;
    }

    public String getSub_cat_name() {
        return sub_cat_name;
    }

    public void setSub_cat_name(String sub_cat_name) {
        this.sub_cat_name = sub_cat_name;
    }

    public int getSub_cat_id() {
        return sub_cat_id;
    }

    public void setSub_cat_id(int sub_cat_id) {
        this.sub_cat_id = sub_cat_id;
    }

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    
}
