package com.tenderhub.model;

import java.util.ArrayList;

public class CategoryLists {
   ArrayList <Product> product_list;
   ArrayList <SubCategory> subcategory_list;
   ArrayList <Category> category_list;

    public CategoryLists(ArrayList<Product> product_list, ArrayList<SubCategory> subcategory_list, ArrayList<Category> category_list) {
        this.product_list = product_list;
        this.subcategory_list = subcategory_list;
        this.category_list = category_list;
    }

    public ArrayList<Product> getProduct_list() {
        return product_list;
    }

    public ArrayList<SubCategory> getSubcategory_list() {
        return subcategory_list;
    }

    public ArrayList<Category> getCategory_list() {
        return category_list;
    }

    public void setProduct_list(ArrayList<Product> product_list) {
        this.product_list = product_list;
    }

    public void setSubcategory_list(ArrayList<SubCategory> subcategory_list) {
        this.subcategory_list = subcategory_list;
    }

    public void setCategory_list(ArrayList<Category> category_list) {
        this.category_list = category_list;
    }
   
   
}
