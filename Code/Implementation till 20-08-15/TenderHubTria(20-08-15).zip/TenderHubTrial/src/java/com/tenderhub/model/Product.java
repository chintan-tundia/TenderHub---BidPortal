package com.tenderhub.model;

public class Product {
    public String name;
    public int product_id;
    public int sub_category_id;

    public Product( int product_id,String name, int sub_category_id) {
        this.name = name;
        this.product_id = product_id;
        this.sub_category_id = sub_category_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getProduct_id() {
        return product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public int getSub_category_id() {
        return sub_category_id;
    }

    public void setSub_category_id(int sub_category_id) {
        this.sub_category_id = sub_category_id;
    }

    
}
